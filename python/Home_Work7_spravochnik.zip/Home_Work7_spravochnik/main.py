# Создать телефонный справочник 
# с возможностью импорта и экспорта данных в нескольких форматах. 
# (txt - csv например).

from controller import*
# from import_number import*
# from export_number import*

hi_command()
deistvie()

#данные на русском не воспринимает, но в экселе все отображается :)